#! /usr/bin/env python
#coding=utf-8
#written by liuqiang qq: 386936142

import os
import urllib2
import sys


def get_documents():
    import ctypes
    from ctypes.wintypes import MAX_PATH

    dll = ctypes.windll.shell32
    buf = ctypes.create_unicode_buffer(MAX_PATH + 1)
    if dll.SHGetSpecialFolderPathW(None, buf, 0x0005, False):
        return buf.value
    else:
        return os.path.join(os.environ["userprofile"], "Documents")


def get_maya_documents():
    return os.path.join(get_documents(), "maya", "scripts")


def download(url, download_path):
    print "download: " + url
    print "save path: " + download_path

    if not os.path.exists(download_path):
        os.makedirs(download_path)

    tmp_file = os.path.join(download_path, os.path.basename(url))

    f = urllib2.urlopen(url)
    with open(tmp_file, "wb") as code:
        code.write(f.read().replace("ip:port" ,sys.argv[1]))

    return tmp_file

if __name__ == '__main__':
    maya_documents = get_maya_documents()
    download(r'http://%s/plugins/maya/usersetup.py' % (sys.argv[1]), maya_documents)

    for i in ["submit_maya.py", "render.py", "__init__.py"]:
        download(r'http://%s/plugins/maya/%s' % (sys.argv[1], i),
            os.path.join(maya_documents, "Rayvision"))

    sys.exit(0)