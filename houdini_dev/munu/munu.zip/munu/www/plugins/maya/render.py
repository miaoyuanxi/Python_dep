#! /usr/bin/env python
#coding=utf-8
#written by liuqiang qq: 386936142

import subprocess
rendercmd = "\"%s\" -s %s -e %s -b %s -rd \"%s\" -mr:art -mr:aml \"%s\"" % (
    render_exe, start, end, byframe, output, maya_file)
#print "start Rayvision render: " + rendercmd

subprocess.call(rendercmd)

print "finished Rayvision render."