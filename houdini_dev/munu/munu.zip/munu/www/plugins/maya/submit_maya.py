#! /usr/bin/env python
#coding=utf-8
#written by liuqiang qq: 386936142

import os
import uuid
import pymel.core as pm
import sys
import urllib2
import urllib


class Task(dict):

    def __init__(self):
        dict.__init__(self)
        self["name"] = "test"
        self["custom"] = "liuqiang"
        self["level"] = "1"
        self["nodelimit"] = "1"
        self["requirements"] = ""
        self["properties"] = ""

        self["jobs"] = []

    def create_frames(self, start, end, group=1, by=1):
        self["jobs"] = []
        start = int(start)
        end = int(end)
        group = int(group)
        by = int(by)

        frames = range(start, end+1, by)
        frames = [frames[i: i+group] for i in range(len(frames))
            if i%group == 0]

        for i in frames:
            frame = Frame(i[0], i[-1], group, by)
            self["jobs"].append(frame)

    def write_to_file(self):
        tmp = os.environ["tmp"]
        if not os.path.exists(tmp):
            os.makedirs(tmp)

        self.submit_file = os.path.join(tmp, str(uuid.uuid1()))

        info = self.format()
        with open(self.submit_file, "w") as f:
            f.write(info)
            f.write("\n")

        print info
        print self.submit_file

    def submit(self):
        info = self.format()
        post_data = "NBBEGIN{%s}NBEND" % (info)
#        print info
#        print post_data

        #http://ip:port/sys/task_create?onstarted=1&script=
        #http://ip:port/sys/task_create?script=

        req = urllib2.urlopen("http://ip:port/sys/task_create?onstarted=1&script=", post_data)
        return req.read()

    def format(self):
        result = "##BEGIN"
        result += "\n"

        for i in self:
            if i != "jobs":
                result += "##%s=%s" % (i, self[i])
                result += "\n"

        result += "##JOBS jobname "
        result += " ".join([i for i in self["jobs"][0].keys()
            if i != "jobname"])
        result += "\n"

        for i_frame in self["jobs"]:
            result += "## %s " % repr(i_frame["jobname"])
            result += " ".join([repr(i_frame[i]) for i in i_frame
                if i != "jobname"])
            result += "\n"

        result += "##ENDJOBS"
        result += "\n"

        result += "##END"
        result += "\n"

        result += self.get_render_code()
        return result

    def get_render_code(self):
        ''

class Frame(dict):

    def __init__(self, start, end, group, by):
        self["start"] = start
        self["end"] = end
        self["byframe"] = by
        self["group"] = group

        if self["start"] == self["end"]:
            self["jobname"] = "frame %s" % (start)
        elif by == 1:
            self["jobname"] = "frame %s-%s" % (start, end)
        else:
            self["jobname"] = "frame %s" % (",".join([str(i)
                for i in range(start, end + 1, by)]))


class MayaTask(Task):

    def __init__(self):
        Task.__init__(self)
        self.render_settings = pm.PyNode("defaultRenderGlobals")

    def get_start_frame(self):
        return int(self.render_settings.startFrame.get())

    def get_end_frame(self):
        return int(self.render_settings.endFrame.get())

    def get_byframe(self):
        return int(self.render_settings.byFrame.get())

    def get_scene_short_name(self):
        return os.path.basename(pm.sceneName())

    def get_scene_name(self):
        return pm.sceneName().encode("gb2312").replace("\\", "/")

    def get_render_exe(self):
        return sys.argv[0].replace("maya.exe", "render.exe").replace("\\", "/")


class SubmitMayaUi(MayaTask):

    def __init__(self):
        MayaTask.__init__(self)
        self.template = self.get_template()
        self.crtl = {}
        self.show_window()
        self.set_default()

    def get_template(self):
        template = pm.uiTemplate('liuqiang_template', force=1)
        template.define(pm.frameLayout, borderVisible=1, labelVisible=0,
            height=30, borderStyle="etchedIn")
        template.define(pm.columnLayout)
        template.define(pm.rowLayout, columnAlign1=('right'), height=30)
        template.define(pm.button, width=100, align='right')
        template.define(pm.text, align='left')
        template.define(pm.textFieldGrp, cl2=["right", "left"], cw2=[100, 50])

        return template

    def show_window(self):
        window_name = "Rayvision submit maya task"

        if pm.window(window_name, q=1, ex=1):
            pm.deleteUI(window_name)
        if pm.windowPref(window_name, exists=1):
            pm.windowPref(window_name, remove=1)

        with pm.window(window_name, sizeable=0) as self.window:
            with self.template:
                with pm.columnLayout():
                    self.crtl["name"] = pm.textFieldGrp(label="name",
                        cw2=[100, 350])
                    self.crtl["custom"] = pm.textFieldGrp(label="custom")
                    self.crtl["level"] = pm.textFieldGrp(label="level")
                    self.crtl["nodelimit"] = pm.textFieldGrp(label="nodelimit")
                    self.crtl["requirements"] = pm.textFieldGrp(label="requirements")
                    self.crtl["properties"] = pm.textFieldGrp(label="properties")
                    with pm.rowLayout(numberOfColumns=4):
                        self.crtl["start"] = pm.textFieldGrp(label="start")
                        self.crtl["end"] = pm.textFieldGrp(label="end",
                            cw2=[40, 50])
                        self.crtl["group"] = pm.textFieldGrp(label="group",
                            cw2=[40, 50])
                        self.crtl["byframe"] = pm.textFieldGrp(label="byframe",
                            cw2=[40, 50])
                    self.crtl["render_exe"] = pm.textFieldGrp(label="render.exe",
                        cw2=[100, 350])
                    self.crtl["output"] = pm.textFieldGrp(label="output",
                        cw2=[100, 350])
                    with pm.rowLayout(numberOfColumns=2, cw2=[100, 100]):
                        pm.text("")
                        self.crtl["submit"] = pm.button(label="SUBMIT",
                            c=self.press_submit)

    def set_default(self):
        self.crtl["name"].setText(self.get_scene_short_name())
        self.crtl["custom"].setText(os.environ["username"])
        self.crtl["level"].setText("1")
        self.crtl["nodelimit"].setText("1")
        self.crtl["requirements"].setText("")
        self.crtl["properties"].setText("")

        self.crtl["start"].setText(self.get_start_frame())
        self.crtl["end"].setText(self.get_end_frame())
        self.crtl["byframe"].setText(self.get_byframe())
        self.crtl["group"].setText("1")
        self.crtl["render_exe"].setText(self.get_render_exe())

    def set_job_info(self):
        for i in self["jobs"]:
            i["render_exe"] = self.crtl["render_exe"].getText().encode("gb2312")
            i["output"] = self.crtl["output"].getText().encode("gb2312").replace("\\", "/")
            i["maya_file"] = self.get_scene_name()

    def press_submit(self, *args):
        for i in self:
            if i != "jobs":
                self[i] = self.crtl[i].getText().encode("gb2312")

        self.create_frames(self.crtl["start"].getText(),
            self.crtl["end"].getText(), self.crtl["group"].getText(),
            self.crtl["byframe"].getText())

        self.set_job_info()

        taskid = str(eval(self.submit())["taskid"])

        pm.confirmDialog(title="Success!", button="OK",
                            message="Submit render task: " + taskid)

        pm.deleteUI(self.window)

    def get_render_code(self):
        render_py = os.path.join(os.path.dirname(__file__), "render.py")
        with open(render_py, "r") as f:
            code = f.read()
        return code
