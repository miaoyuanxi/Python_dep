#! /usr/bin/env python
#coding=utf-8
#written by liuqiang qq: 386936142

import pymel.core as pm
import pymel.all as pa

def install_rayvision():
    if not "MayaWindow|Rayvision" in pm.lsUI(type="menu"):
        pm.menu("Rayvision", parent='MayaWindow')
        pm.menuItem("SubmitMayaRenderTask",
            command="import Rayvision.submit_maya;Rayvision.submit_maya.SubmitMayaUi()")

pa.mayautils.executeDeferred(install_rayvision)
