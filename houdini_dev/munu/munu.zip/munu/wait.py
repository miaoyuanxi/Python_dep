#!/usr/bin/python
import time

#script_param_mark#

##BEGIN
##name=test-task
##description=this is a test task
##custom=test
##level=50
##interruptible=false
##nodeunit=1
##nodelimit=20
##nodeblacklimit=3
##properties=
##requirements=
##constraints=
##frequencytime=
##frequencycount=
##JOBS     G_JOB_ID      G_WAIT_TIMES
##          "job1"            8
##          "job2"            8
##          "job3"            8
##          "job4"            8
##ENDJOBS
##END

for i in range(0, G_WAIT_TIMES, 1):
    print("%d" % i)
    print("    Start : %s" % time.ctime())
    time.sleep(1)
    print("    End : %s" % time.ctime())
    time.sleep(1)
print("Done")
