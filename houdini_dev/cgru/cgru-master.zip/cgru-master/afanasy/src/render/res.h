#pragma once

#include "../libafanasy/host.h"

void GetResources( af::Host & host, af::HostRes & hres, bool verbose = false);
