#include "msgclass.h"

using namespace af;

MsgClass::MsgClass()
{
};

MsgClass::~MsgClass(){};
