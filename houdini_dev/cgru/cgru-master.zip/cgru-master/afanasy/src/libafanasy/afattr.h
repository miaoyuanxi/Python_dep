#pragma once
/*
#include <QtCore/QString>

struct Attribute
{
   QString shortname;
//   char * shortname;
   QString name;
   QString longname;
   int initvalue;
   int minimum;
   int maximum;
   bool calculated;
};

namespace af
{
/// Afanasy attribute class
class AfAttr
{
public:
   AfAttr();

/// Attributes types:
enum Type{
   TNULL,

   TINTEGER_BEGIN,
      TPriority,
      TMaxHosts,
   TINTEGER_END,

   TSTRING_BEGIN,
      TJobName,
      TUserName,
      THostName,
   TSTRING_END,

   TLAST
};

 static Attribute AT[10];
enum Type{
   TNULL,

   TInt,
   TString,

   TLAST
};
   static void initAll();

   inline int getType() const { return type;}

public:
//   inline virtual int type() const { return TNULL;}
//   inline virtual int type1() const { return TInt;}
   static const int type;
//   int i;
};
}
*/
