#include "afattr.h"
/*
using namespace af;

Attribute AfAttr::AT[TLAST];

void AfAttr::initAll()
{
   AT[TUserName] = { "user", "User name", "", -1, 0, 0};
}
*/
