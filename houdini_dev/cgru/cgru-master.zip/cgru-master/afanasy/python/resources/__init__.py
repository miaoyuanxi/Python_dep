print 'Init resources'
