# -*- coding: utf-8 -*-

from services import service

parser = 'hbatch_redshift'


class hbatch_redshift(service.service):
    """Houdini batch executes redshift
    """
    pass
