# -*- coding: utf-8 -*-
from services import service

parser = 'max'


class max(service.service):
    """3ds Max
    """
    pass
