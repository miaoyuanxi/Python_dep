# -*- coding: utf-8 -*-
from services import service

parser = 'mayatovray'


class mayatovray(service.service):
    """Autodesk Maya to VRay Standalone
    """
    pass
