# -*- coding: utf-8 -*-
from services import service


class postcmd(service.service):
    """Job and Block post commands (on job deletion)
    """
    pass
