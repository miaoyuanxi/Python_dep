# -*- coding: utf-8 -*-
from services import service

parser = 'xsi_arnold_watermarked'


class xsi_arnold_watermarked(service.service):
    'Arnold - watermarked'
