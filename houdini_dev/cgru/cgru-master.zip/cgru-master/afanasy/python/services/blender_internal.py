# -*- coding: utf-8 -*-
from services import service

parser = 'blender_internal'


class blender_internal(service.service):
    """Blender batch with internal render engine
    """
    pass
