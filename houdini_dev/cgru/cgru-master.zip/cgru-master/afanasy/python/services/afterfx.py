# -*- coding: utf-8 -*-
from services import service

parser = 'afterfx'


class afterfx(service.service):
    """Adobe After Effects
    """
    pass
