# -*- coding: utf-8 -*-
from services import service

parser = 'xsi_arnold'


class xsi_arnold(service.service):
    'Arnold'
