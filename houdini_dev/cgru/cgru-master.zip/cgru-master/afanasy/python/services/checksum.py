# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class checksum(service.service):
    """Calculate checksum
    """
    pass
