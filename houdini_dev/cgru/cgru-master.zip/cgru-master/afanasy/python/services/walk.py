# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class walk(service.service):
    """RULES filesystem Walk service
    """
    pass
