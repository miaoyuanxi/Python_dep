# -*- coding: utf-8 -*-
from services import service

parser = 'maya_arnold'


class maya_arnold(service.service):
    """Maya To Arnold
    """
    pass
