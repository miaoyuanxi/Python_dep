# -*- coding: utf-8 -*-
from services import service

parser = 'hbatch_prman'


class hbatch_prman(service.service):
    """Houdini batch executes prman
    """
    pass
