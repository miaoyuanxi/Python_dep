# -*- coding: utf-8 -*-
from services import service

parser = 'hbatch_mantra'


class hbatch_mantra(service.service):
    """Houdini batch execute mantra
    """
    pass
