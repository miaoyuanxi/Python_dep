# -*- coding: utf-8 -*-
from services import service

parser = 'xsi_redshift'


class xsi_redshift(service.service):
    """Redshift
    """
    pass
