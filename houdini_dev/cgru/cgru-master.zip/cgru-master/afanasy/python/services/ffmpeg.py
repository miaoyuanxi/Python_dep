# -*- coding: utf-8 -*-
from services import service

parser = 'ffmpeg'


class ffmpeg(service.service):
    """Process through ffmpeg
    """
    pass
