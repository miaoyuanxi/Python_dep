# -*- coding: utf-8 -*-
from services import service

parser = 'natron'


class natron(service.service):
    """Natron
    """
    pass
