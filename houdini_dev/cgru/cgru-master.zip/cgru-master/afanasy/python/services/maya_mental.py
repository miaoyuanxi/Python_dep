# -*- coding: utf-8 -*-
from services import service

parser = 'maya_mental'


class maya_mental(service.service):
    """Maya To Mental Ray
    """
    pass
