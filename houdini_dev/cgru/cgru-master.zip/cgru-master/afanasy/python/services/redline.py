# -*- coding: utf-8 -*-
from services import service

parser = 'redline'


class redline(service.service):
    """redline
    """
    pass
