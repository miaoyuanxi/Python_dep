# -*- coding: utf-8 -*-
from services import service

parser = 'rsync'


class rsync(service.service):
    """rsync
    """
    pass
