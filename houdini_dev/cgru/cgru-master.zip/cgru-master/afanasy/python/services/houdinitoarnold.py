# -*- coding: utf-8 -*-
from services import service

parser = 'houdinitoarnold'


class houdinitoarnold(service.service):
    """Houdini to Arnold Standalone
    """
    pass
