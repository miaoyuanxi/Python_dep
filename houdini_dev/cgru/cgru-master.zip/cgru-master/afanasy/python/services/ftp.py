# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class ftp(service.service):
    """FTP
    """
    pass
