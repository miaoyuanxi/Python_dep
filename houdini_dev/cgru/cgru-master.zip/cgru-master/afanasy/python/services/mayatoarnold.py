# -*- coding: utf-8 -*-
from services import service

parser = 'mayatoarnold'


class mayatoarnold(service.service):
    """Autodesk Maya to Arnold Standalone
    """
    pass
