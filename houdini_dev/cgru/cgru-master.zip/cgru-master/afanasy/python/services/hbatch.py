# -*- coding: utf-8 -*-
from services import service

parser = 'hbatch'


class hbatch(service.service):
    """Houdini batch
    """
    pass
