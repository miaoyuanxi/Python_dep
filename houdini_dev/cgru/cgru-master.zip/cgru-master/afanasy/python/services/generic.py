# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class generic(service.service):
    """Simple service for anything
    """
    pass
