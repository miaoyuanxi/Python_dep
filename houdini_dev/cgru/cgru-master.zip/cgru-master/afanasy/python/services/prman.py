# -*- coding: utf-8 -*-
from services import service

parser = 'prman'


class prman(service.service):
    """PIXAR's RenderMan
    """
    pass
