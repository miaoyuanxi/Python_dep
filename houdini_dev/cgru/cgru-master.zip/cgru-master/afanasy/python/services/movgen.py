# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class movgen(service.service):
    """Service for movies generation. Annotate and encode to make dailies.
    """
    pass
