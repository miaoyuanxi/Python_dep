# -*- coding: utf-8 -*-
from services import service

parser = 'mantra'


class mantra(service.service):
    """Houdini mantra
    """
    pass
