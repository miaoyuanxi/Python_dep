# -*- coding: utf-8 -*-

from services import service

parser = 'fusion'


class fusion(service.service):
    """ Fusion
    """
    pass
