# -*- coding: utf-8 -*-
from services import service

parser = 'arnold'


class arnold(service.service):
    """Arnold Standalone
    """
    pass
