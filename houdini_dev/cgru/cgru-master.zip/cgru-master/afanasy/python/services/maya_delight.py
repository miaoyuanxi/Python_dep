# -*- coding: utf-8 -*-
from services import service

parser = 'maya_delight'


class maya_delight(service.service):
    """3Delight For Maya
    """
    pass
