# -*- coding: utf-8 -*-
from services import service

parser = 'nuke'


class nuke(service.service):
    """The Foundry Nuke
    """
    pass
