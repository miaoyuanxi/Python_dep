# -*- coding: utf-8 -*-
from services import service

parser = 'c4d'


class c4d(service.service):
    """MAXON Cinema 4D
    """
    pass
