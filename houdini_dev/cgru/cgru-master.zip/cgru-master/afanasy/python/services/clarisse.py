# -*- coding: utf-8 -*-
from services import service

parser = 'clarisse'


class clarisse(service.service):
    """Isotropix Clarisse
    """
    pass
