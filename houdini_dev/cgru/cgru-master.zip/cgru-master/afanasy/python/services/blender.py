# -*- coding: utf-8 -*-
from services import service

parser = 'blender'


class blender(service.service):
    """Blender batch
    """
    pass
