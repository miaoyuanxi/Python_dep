# -*- coding: utf-8 -*-
from services import service

parser = 'maya_redshift'


class maya_redshift(service.service):
    """Redshift
    """
    pass
