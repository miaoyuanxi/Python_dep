# -*- coding: utf-8 -*-
from services import service

parser = 'mayatomr'


class mayatomr(service.service):
    """Autodesk Maya to MentalRay Standalone
    """
    pass
