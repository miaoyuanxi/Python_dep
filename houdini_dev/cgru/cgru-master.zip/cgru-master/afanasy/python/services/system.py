# -*- coding: utf-8 -*-
from services import service

parser = 'generic'


class system(service.service):
    """Service for system tasks.
    """
    pass
