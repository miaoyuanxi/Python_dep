# -*- coding: utf-8 -*-
from services import service

parser = 'xsi'


class xsi(service.service):
    """Softimage
    """
    pass
