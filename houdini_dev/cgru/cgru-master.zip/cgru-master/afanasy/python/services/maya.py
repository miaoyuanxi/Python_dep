# -*- coding: utf-8 -*-
from services import service

parser = ''


class maya(service.service):
    """Autodesk Maya
    """
    pass
