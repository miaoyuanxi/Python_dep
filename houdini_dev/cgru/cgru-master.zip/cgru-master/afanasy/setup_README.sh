#!/bin/bash

# You can put files named "setup_*.sh" in this folder.
# They all will be sourced from "setup.sh".
